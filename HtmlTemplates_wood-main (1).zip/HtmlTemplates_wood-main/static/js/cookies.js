document.addEventListener('DOMContentLoaded', () => {
    const banner = document.getElementById('cw-cookie-banner');
    if (!banner) {
        console.error('Cookie banner element not found');
        return;
    }

    // Get all elements with null checks
    const elements = {
        details: document.getElementById('cw-cookie-details'),
        acceptBtn: document.getElementById('cw-accept-all'),
        rejectBtn: document.getElementById('cw-reject-all'),
        saveBtn: document.getElementById('cw-save-settings'),
        showBtn: document.getElementById('cw-show-details'),
        hideBtn: document.getElementById('cw-hide-details'),
        langCheck: document.getElementById('cw-lang-cookies'),
        socialCheck: document.getElementById('cw-social-cookies')
    };

    // Verify all required elements exist
    const requiredElements = ['details', 'showBtn', 'hideBtn', 'acceptBtn', 'rejectBtn'];
    const missingElements = requiredElements.filter(key => !elements[key]);
    
    if (missingElements.length > 0) {
        console.error('Missing required elements:', missingElements);
        return;
    }

    // Initialize banner state
    if (!localStorage.getItem('cw-cookie-consent')) {
        banner.classList.remove('hidden');
        banner.style.opacity = '1';
        banner.style.transform = 'translate(-50%, 0)';
    }

    // Event listeners
    elements.showBtn.addEventListener('click', showDetails);
    elements.hideBtn.addEventListener('click', hideDetails);
    elements.acceptBtn.addEventListener('click', () => handleConsent(true, true));
    elements.rejectBtn.addEventListener('click', () => handleConsent(false, false));
    elements.saveBtn?.addEventListener('click', () => {
        handleConsent(
            elements.langCheck?.checked || false,
            elements.socialCheck?.checked || false
        );
    });

    function showDetails() {
        elements.details.classList.remove('hidden');
        elements.showBtn.classList.add('hidden');
        elements.hideBtn.classList.remove('hidden');
        elements.acceptBtn.classList.add('hidden');
        elements.rejectBtn.classList.add('hidden');
        elements.saveBtn?.classList.remove('hidden');
    }

    function hideDetails() {
        elements.details.classList.add('hidden');
        elements.showBtn.classList.remove('hidden');
        elements.hideBtn.classList.add('hidden');
        elements.acceptBtn.classList.remove('hidden');
        elements.rejectBtn.classList.remove('hidden');
        elements.saveBtn?.classList.add('hidden');
    }

    function handleConsent(langAllowed, socialAllowed) {
        const consent = {
            essential: true,
            language: langAllowed,
            social: socialAllowed,
            timestamp: new Date().toISOString()
        };
        
        localStorage.setItem('cw-cookie-consent', JSON.stringify(consent));
        hideBanner();
        
        if (langAllowed && typeof initializeI18n === 'function') {
            initializeI18n();
        }
    }

    function hideBanner() {
        banner.style.opacity = '0';
        banner.style.transform = 'translate(-50%, 100%)';
        setTimeout(() => banner.classList.add('hidden'), 300);
    }
});