document.addEventListener('DOMContentLoaded', () => {
  const profileBtn = document.getElementById('js-profile-btn');
  const profileDropdown = document.getElementById('js-profile-dropdown');

  if (!profileBtn || !profileDropdown) {
    console.error('Profile elements missing');
    return;
  }

  profileBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    profileDropdown.classList.toggle('show');
  });

  document.addEventListener('click', () => {
    profileDropdown.classList.remove('show');
  });
});