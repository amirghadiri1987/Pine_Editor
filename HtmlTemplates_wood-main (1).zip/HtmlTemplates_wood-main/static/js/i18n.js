let currentTranslations = {};

async function initializeI18n() {
    try {
        const lang = localStorage.getItem('cw-preferredLanguage') || 'en';
        const response = await fetch(`/static/lang/${lang}.json`);
        currentTranslations = await response.json();
        applyTranslations();
    } catch (error) {
        console.error('Failed to load translations:', error);
    }
}

function applyTranslations() {
    // Set document direction
    const lang = document.documentElement.getAttribute('lang');
    const dir = lang === 'ar' || lang === 'fa' ? 'rtl' : 'ltr';
    document.body.setAttribute('dir', dir);
    
    // Apply translations
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        el.textContent = currentTranslations[key] || key;
    });
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initializeI18n);