document.addEventListener('DOMContentLoaded', () => {
    // Social Dropdown
    const socialIcon = document.getElementById('social-icon');
    const socialDropdown = document.getElementById('social-dropdown');

    socialIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        socialDropdown.classList.toggle('show');
    });

    document.addEventListener('click', (e) => {
        if (!socialDropdown.contains(e.target) && !socialIcon.contains(e.target)) {
            socialDropdown.classList.remove('show');
        }
    });

    // Language Switching
    const langButtons = document.querySelectorAll('[data-lang]');
    const savedLang = getCookie('site_lang') || 'en';

    loadLanguage(savedLang); // Load on page load
    setCurrentLangFlag(savedLang); // Optional UI update

    langButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const selectedLang = btn.getAttribute('data-lang');
            setCookie('site_lang', selectedLang, 30);
            loadLanguage(selectedLang);
            setCurrentLangFlag(selectedLang); // Optional UI
        });
    });
});

// Cookie utilities
function setCookie(name, value, days) {
    const expires = new Date(Date.now() + days*24*60*60*1000).toUTCString();
    document.cookie = `${name}=${value}; expires=${expires}; path=/`;
}

function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : null;
}

// Optional: updates flag UI for active lang
function setCurrentLangFlag(langCode) {
    const current = document.querySelector('.current-lang-flag');
    if (current) current.src = `./flags/${langCode}.svg`;
}
