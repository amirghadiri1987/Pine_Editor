// static/js/i18n.js
const COOKIE_KEY = 'cookieConsent';
const LANG_KEY = 'preferredLanguage';
const defaultLang = 'en';
const supportedLangs = ['en', 'fa', 'ar'];

export async function initializeI18n() {
    const savedConsent = JSON.parse(localStorage.getItem(COOKIE_KEY));
    const langAllowed = savedConsent?.language;
    let lang = defaultLang;

    if (langAllowed) {
        const storedLang = localStorage.getItem(LANG_KEY);
        if (storedLang && supportedLangs.includes(storedLang)) {
            lang = storedLang;
        }
    }

    await loadLanguage(lang);
}

async function loadLanguage(lang) {
    try {
        const response = await fetch(`static/lang/${lang}.json`);
        const translations = await response.json();

        applyTranslations(translations);

        // Set HTML attributes for language and direction
        document.documentElement.setAttribute('lang', lang);
        document.body.setAttribute('dir', lang === 'fa' || lang === 'ar' ? 'rtl' : 'ltr');

        // Save language to localStorage if consented
        const savedConsent = JSON.parse(localStorage.getItem(COOKIE_KEY));
        if (savedConsent?.language) {
            localStorage.setItem(LANG_KEY, lang);
        }
    } catch (err) {
        console.error(`Failed to load language file: ${lang}`, err);
    }
}

function applyTranslations(data) {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (data[key]) el.textContent = data[key];
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (data[key]) el.placeholder = data[key];
    });
}