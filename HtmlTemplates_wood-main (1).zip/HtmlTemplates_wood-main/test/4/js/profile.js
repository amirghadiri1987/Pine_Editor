// static/js/profile.js
document.addEventListener('DOMContentLoaded', () => {
  const profileBtn = document.getElementById('js-profile-btn');
  const dropdown = document.getElementById('js-profile-dropdown');

  profileBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    dropdown.classList.toggle('show');
  });

  // Close when clicking outside
  document.addEventListener('click', () => {
    dropdown.classList.remove('show');
  });
});