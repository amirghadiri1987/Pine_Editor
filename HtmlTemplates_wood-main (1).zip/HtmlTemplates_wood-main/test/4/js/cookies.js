document.addEventListener('DOMContentLoaded', () => {
    const banner = document.getElementById('cw-cookie-banner');
    const acceptAllBtn = document.getElementById('cw-accept-all');
    const rejectAllBtn = document.getElementById('cw-reject-all');
    const saveSettingsBtn = document.getElementById('cw-save-settings');
    const showDetailsBtn = document.getElementById('cw-show-details');
    const hideDetailsBtn = document.getElementById('cw-hide-details');
    const detailsPanel = document.getElementById('cw-cookie-details');
    const langCheckbox = document.getElementById('cw-lang-cookies');
    const socialCheckbox = document.getElementById('cw-social-cookies');

    // Show banner only if not previously accepted/rejected
    if (!localStorage.getItem('cw-cookie-consent')) {
        banner.classList.remove('hidden');
    }

    acceptAllBtn.addEventListener('click', () => {
        saveConsent({ language: true, social: true });
        hideBanner();
    });

    rejectAllBtn.addEventListener('click', () => {
        saveConsent({ language: false, social: false });
        hideBanner();
    });

    showDetailsBtn.addEventListener('click', () => {
        detailsPanel.classList.remove('hidden');
        acceptAllBtn.classList.add('hidden');
        rejectAllBtn.classList.add('hidden');
        saveSettingsBtn.classList.remove('hidden');
        showDetailsBtn.classList.add('hidden');
        hideDetailsBtn.classList.remove('hidden');
    });

    hideDetailsBtn.addEventListener('click', () => {
        detailsPanel.classList.add('hidden');
        acceptAllBtn.classList.remove('hidden');
        rejectAllBtn.classList.remove('hidden');
        saveSettingsBtn.classList.add('hidden');
        showDetailsBtn.classList.remove('hidden');
        hideDetailsBtn.classList.add('hidden');
    });

    saveSettingsBtn.addEventListener('click', () => {
        const settings = {
            language: langCheckbox.checked,
            social: socialCheckbox.checked,
        };
        saveConsent(settings);
        hideBanner();
    });

    function saveConsent(preferences) {
        const data = {
            ...preferences,
            essential: true,
            timestamp: new Date().toISOString()
        };
        localStorage.setItem('cw-cookie-consent', JSON.stringify(data));

        if (!preferences.language) {
            localStorage.removeItem('cw-preferredLanguage');
        }
    }

    function hideBanner() {
        banner.classList.add('hidden');
    }
});
