// static/js/i18n.js
const COOKIE_KEY = 'cookieConsent';
const LANG_KEY = 'preferredLanguage';
const defaultLang = 'en';
const supportedLangs = ['en', 'fa', 'ar'];

export async function initializeI18n() {
    const savedConsent = JSON.parse(localStorage.getItem(COOKIE_KEY));
    const langAllowed = savedConsent?.language;
    let lang = defaultLang;

    if (langAllowed) {
        const storedLang = localStorage.getItem(LANG_KEY);
        if (storedLang && supportedLangs.includes(storedLang)) {
            lang = storedLang;
        }
    }

    await loadLanguage(lang);
}

async function loadLanguage(language) {
    try {
        const response = await fetch(`static/lang/${language}.json`);
        const translations = await response.json();
        applyTranslations(translations);
    } catch (error) {
        console.error(`Failed to load ${language}.json`, error);
    }
}

function applyTranslations(data) {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (data[key]) el.innerText = data[key];
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (data[key]) el.placeholder = data[key];
    });
}
