document.addEventListener('DOMContentLoaded', () => {
    const banner = document.getElementById('cookie-banner');
    const details = document.getElementById('cookie-details');
    const acceptAllBtn = document.getElementById('accept-all');
    const rejectAllBtn = document.getElementById('reject-all');
    const settingsBtn = document.getElementById('cookie-settings');

    const langCheckbox = document.getElementById('lang-cookies');
    const socialCheckbox = document.getElementById('social-cookies');

    const COOKIE_KEY = 'cookieConsent';

    // Load cookie consent
    const savedConsent = JSON.parse(localStorage.getItem(COOKIE_KEY));

    if (!savedConsent) {
        banner.classList.remove('hidden');
    } else {
        applyPreferences(savedConsent);
    }

    // Handle Accept All
    acceptAllBtn.addEventListener('click', () => {
        const consent = {
            essential: true,
            language: true,
            social: true
        };
        localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
        applyPreferences(consent);
        banner.classList.add('hidden');
    });

    // Handle Reject All
    rejectAllBtn.addEventListener('click', () => {
        const consent = {
            essential: true,
            language: false,
            social: false
        };
        localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
        applyPreferences(consent);
        banner.classList.add('hidden');
    });

    // Show settings
    settingsBtn.addEventListener('click', () => {
        details.classList.toggle('hidden');
    });

    // Apply preferences on load or after change
    function applyPreferences(consent) {
        // Language: allow saving language cookie only if permitted
        window.languageCookiesAllowed = !!consent.language;

        // Social: you can conditionally load social scripts here
        if (!consent.social) {
            // Example: disable social sharing
            console.log("Social cookies disabled");
        }
    }
});
