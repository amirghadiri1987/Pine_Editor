// static/js/main.js
import { initializeI18n } from './i18n.js';

document.addEventListener('DOMContentLoaded', () => {
    initializeI18n(); // Load translations first

    const profileIcon = document.getElementById('profile-icon');
    const profileDropdown = document.getElementById('profile-dropdown');
    const socialIcon = document.getElementById('social-icon');
    const socialDropdown = document.getElementById('social-dropdown');

    // Toggle Profile
    profileIcon?.addEventListener('click', (e) => {
        e.stopPropagation();
        // Close social if open
        socialDropdown?.classList.remove('show');
        profileDropdown?.classList.toggle('show');
    });

    // Toggle Social
    socialIcon?.addEventListener('click', (e) => {
        e.stopPropagation();
        // Close profile if open
        profileDropdown?.classList.remove('show');
        socialDropdown?.classList.toggle('show');
    });

    // Close both if clicked outside
    document.addEventListener('click', (e) => {
        if (!profileDropdown?.contains(e.target) && !profileIcon?.contains(e.target)) {
            profileDropdown?.classList.remove('show');
        }
        if (!socialDropdown?.contains(e.target) && !socialIcon?.contains(e.target)) {
            socialDropdown?.classList.remove('show');
        }
    });

    // Close both on Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            profileDropdown?.classList.remove('show');
            socialDropdown?.classList.remove('show');
        }
    });
});
