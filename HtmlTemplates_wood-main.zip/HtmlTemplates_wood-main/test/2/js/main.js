// static/js/main.js
import { initializeI18n } from './i18n.js';



// Profile Dropdown Logic
document.addEventListener('DOMContentLoaded', () => {
    initializeI18n(); // Ensure i18n is initialized first

    // Profile Dropdown Logic
    const profileIcon = document.getElementById('profile-icon');
    const profileDropdown = document.getElementById('profile-dropdown');

    profileIcon?.addEventListener('click', (e) => {
        e.stopPropagation(); // prevent bubbling to document
        profileDropdown?.classList.toggle('show');
    });

    // Social Dropdown Logic
    const socialIcon = document.getElementById('social-icon');
    const socialDropdown = document.getElementById('social-dropdown');

    socialIcon?.addEventListener('click', (e) => {
        e.stopPropagation();
        socialDropdown?.classList.toggle('show');
    });

    // Close all dropdown on outside click
    document.addEventListener('click', (e) => {
        if (!profileDropdown?.contains(e.target) && !profileIcon?.contains(e.target)) {
            profileDropdown?.classList.remove('show');
        }
        if (!socialDropdown.contains(e.target) && !socialIcon.contains(e.target)) {
            socialDropdown.classList.remove('show');
        }
    });

    // Close all dropdown on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            profileDropdown?.classList.remove('show');
            socialDropdown?.classList.remove('show');
        }
    });
});
