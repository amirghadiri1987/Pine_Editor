// static/js/main.js
import { initializeI18n } from './i18n.js';

document.addEventListener('DOMContentLoaded', () => {
    initializeI18n(); // Load langguage on DOM ready

    // Dropdown Elements
    const dropdowns = [
        { icon: 'profile-icon', menu: 'profile-dropdown' },
        { icon: 'social-icon', menu: 'social-dropdown' },
        { icon: 'notification-icon', menu: 'notification-dropdown' }
    ];

    dropdowns.forEach(({ icon, menu }) => {
        const iconEl = document.getElementById(icon);  // ← Corrected to "iconEl"
        const menuEl = document.getElementById(menu);

        iconEl?.addEventListener('click', (e) => {     // ← Now using "iconEl"
            e.stopPropagation();
            closeAllDropdownsExcept(menu);
            menuEl?.classList.toggle('show');
        });
    });

    // Close all on click outside
    document.addEventListener('click', () => closeAllDropdowns());

    // Close all on Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeAllDropdowns();
    });

    function closeAllDropdowns() {
        dropdowns.forEach(({ menu }) => {
            document.getElementById(menu)?.classList.remove('show');
        });
    }

    function closeAllDropdownsExcept(exceptId) {
        dropdowns.forEach(({ menu }) => {
            if (menu !== exceptId) {
                document.getElementById(menu)?.classList.remove('show');
            }
        });
    }
});
