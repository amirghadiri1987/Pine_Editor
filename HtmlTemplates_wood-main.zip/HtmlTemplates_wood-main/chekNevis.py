<div class="profile-menu">
                        <button id="profile-icon" class="header-icon">
                            <img src="static/img/default-profile.png" alt="Profile" class="profile-image">
                        </button>
                        <div class="dropdown" id="profile-dropdown">
                            <div class="dropdown-top">
                                <img src="static/img/default-profile.png" alt="Profile" class="dropdown-profile-pic">
                                <strong class="dropdown-name" data-i18n="guest_user">Guest User</strong>
                                <input type="text" placeholder="Enter your status" class="dropdown-status"
                                    data-i18n-placeholder="status_placeholder">
                            </div>
                            <ul class="dropdown-list">
                                <li><i class="fa-solid fa-user"></i> <span data-i18n="profile">Profile</span></li>
                                <li><i class="fa-solid fa-gauge"></i> <span data-i18n="dashboard">Dashboard</span></li>
                                <li><i class="fa-solid fa-receipt"></i> <span data-i18n="my_salary">My Salary</span>
                                </li>
                                <li><i class="fa-solid fa-gear"></i> <span data-i18n="settings">Settings</span></li>
                            </ul>
                            <div class="dropdown-footer">
                                <button class="signout-btn">
                                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                                    <span data-i18n="logout">Logout</span>
                                </button>
                            </div>
                        </div>
                    </div>
