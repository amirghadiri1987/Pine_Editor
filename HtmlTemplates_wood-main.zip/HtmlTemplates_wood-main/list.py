1. Project Setup & Core Files
Root Files

index.html (Main HTML skeleton)

/static/css/core.css (CSS variables + reset)

Base CSS Structure

Define :root variables (colors, fonts, spacing)

Add a CSS reset (normalize.css or minimal custom reset)

2. Layout Components
A. Fixed Header
HTML Structure (index.html)

Split into 3 sections: cw-header__left, cw-header__middle, cw-header__right

Include logo, sidebar toggle, notification button, etc.

CSS Styling (/static/css/components/_header.scss or main.css)

Flexbox/Grid layout

Theming support (dark/light)

B. Sidebar
HTML Structure

Nested <nav> with accounting menu items

Collapsible submenus

CSS Styling

RTL/LTR support

Animation for toggle

3. Functional Systems
A. Multilingual (i18n)
Translation Files

/static/lang/en.json, fa.json, ar.json

Keys for all UI text (header, sidebar, notifications)

JavaScript Integration

i18n.js: Load language based on cookie/localStorage

Language switcher UI in header

B. Cookie Consent
Cookie Logic (cookies.js)

Check/set consent

Store language/theme preferences

UI Banner

Translated messages

Accept/Reject buttons

4. Advanced Features
Secret Admin Panel

Hidden toggle (triple-click)

Controls for theme, RTL, sidebar position

Theme Engine

Dark/light mode

Auto-schedule (sunrise/sunset)

5. Final Integration
Load Order in index.html