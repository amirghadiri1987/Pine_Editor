document.addEventListener('DOMContentLoaded', function () {
  const profileBtn = document.getElementById('js-profile-btn');
  const profileDropdown = document.getElementById('js-profile-dropdown');

  // Toggle dropdown
  profileBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    profileDropdown.classList.toggle('show');
  });

  // Close when clicking outside
  document.addEventListener('click', function (e) {
    if (!profileDropdown.contains(e.target) && !profileBtn.contains(e.target)) {
      profileDropdown.classList.remove('show');
    }
  });

  // Close on Escape key
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      profileDropdown.classList.remove('show');
    }
  });
});