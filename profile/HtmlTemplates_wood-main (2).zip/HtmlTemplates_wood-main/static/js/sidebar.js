document.querySelector('.js-sidebar-toggle').addEventListener('click', () => {
  const sidebar = document.getElementById('js-sidebar');
  sidebar.classList.toggle('cw-sidebar--collapsed');
});