<!-- Profile Button -->
            <div class="cw-profile-menu">
                <button id="js-profile-btn" class="cw-header__icon" aria-label="Profile">
                    <img src="/static/img/default-profile.png" alt="Profile" class="cw-profile__image">
                </button>

                <div class="cw-dropdown" id="js-profile-dropdown">
                    <div class="cw-dropdown__top">
                        <img src="/static/img/default-profile.png" alt="Profile" class="cw-dropdown__pic">
                        <strong class="cw-dropdown__name" data-i18n="guest_user">Guest User</strong>
                        <input type="text" class="cw-dropdown__status" data-i18n="status_placeholder"
                            placeholder="Update your status">
                    </div>

                    <ul class="cw-dropdown__list">
                        <li data-i18n="menu_profile"><i class="fas fa-user"></i> Profile</li>
                        <li data-i18n="menu_dashboard"><i class="fas fa-gauge"></i> Dashboard</li>
                        <li data-i18n="menu_payments"><i class="fas fa-receipt"></i> My Payments</li>
                        <li data-i18n="menu_settings"><i class="fas fa-gear"></i> Settings</li>
                    </ul>

                    <div class="cw-dropdown__footer">
                        <button class="cw-signout-btn" data-i18n="menu_signout">
                            <i class="fas fa-arrow-right-from-bracket"></i>
                            Sign Out
                        </button>
                    </div>
                </div>
            </div>
















<!-- Cookie Banner (place right after <body>) -->
    <div id="cw-cookie-banner" class="cw-cookie-banner hidden" dir="auto">
        <div class="cw-cookie-content">
            <div class="cw-cookie-text">
                <p data-i18n="cookie_message">test</p>
                <p data-i18n="cookie_policy_info"></p>
            </div>

            <div id="cw-cookie-details" class="cw-cookie-details hidden">
                <h4 data-i18n="cookie_preferences"></h4>
                <p data-i18n="cookie_explanation"></p>

                <div class="cw-cookie-option">
                    <label>
                        <input type="checkbox" disabled checked>
                        <strong data-i18n="essential_cookies"></strong>
                    </label>
                    <p class="cw-cookie-desc" data-i18n="essential_desc"></p>
                </div>

                <div class="cw-cookie-option">
                    <label>
                        <input type="checkbox" id="cw-lang-cookies" checked>
                        <strong data-i18n="language_cookies"></strong>
                    </label>
                    <p class="cw-cookie-desc" data-i18n="language_desc"></p>
                </div>

                <div class="cw-cookie-option">
                    <label>
                        <input type="checkbox" id="cw-social-cookies">
                        <strong data-i18n="social_cookies"></strong>
                    </label>
                    <p class="cw-cookie-desc" data-i18n="social_desc"></p>
                </div>
            </div>

            <div class="cw-cookie-actions">
                <button id="cw-accept-all" class="cw-btn cw-btn--primary" data-i18n="accept_all"></button>
                <button id="cw-reject-all" class="cw-btn cw-btn--secondary" data-i18n="reject_all"></button>
                <button id="cw-cookie-settings" class="cw-btn cw-btn--text" data-i18n="show_details"></button>
                <button id="cw-save-settings" class="cw-btn cw-btn--primary hidden" data-i18n="save_settings"></button>
            </div>
        </div>
    </div>