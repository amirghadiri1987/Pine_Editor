// static/js/main.js
import { initializeI18n } from './i18n.js';

document.addEventListener('DOMContentLoaded', () => {
    initializeI18n();
});


// Profile Dropdown Logic
document.addEventListener('DOMContentLoaded', () => {
    const profileIcon = document.getElementById('profile-icon');
    const dropdown = document.getElementById('profile-dropdown');

    profileIcon.addEventListener('click', (e) => {
        e.stopPropagation(); // prevent bubbling to document
        dropdown.classList.toggle('show');
    });

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target) && !profileIcon.contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });

    // Close dropdown on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            dropdown.classList.remove('show');
        }
    });
});
